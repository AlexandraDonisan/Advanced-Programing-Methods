package Model;

public abstract class Expr {
    public abstract Integer eval();

}
